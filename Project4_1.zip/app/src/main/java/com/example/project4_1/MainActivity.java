package com.example.project4_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edit1,edit2;
    Button btnAdd,btnSub,btnMul,btnDiv;
    TextView textResult;
    String num1,num2;
    Double result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("계산기");
        edit1 = findViewById(R.id.edit1);
        edit2 = findViewById(R.id.edit2);
        btnAdd = findViewById(R.id.btnAdd);
        textResult = findViewById(R.id.textResult);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1 = edit1.getText().toString();
                num2= edit2.getText().toString();
                result= Double.parseDouble(num1)+Double.parseDouble(num2);
                textResult.setText("계산결과:"+result.toString());

            }
        });
        btnSub = findViewById(R.id.btnSub);
        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1 = edit1.getText().toString();
                num2= edit2.getText().toString();
                result= Double.parseDouble(num1)-Double.parseDouble(num2);
                textResult.setText("계산결과:"+result.toString());
            }
        });
        btnMul = findViewById(R.id.btnMul);
        btnMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1 = edit1.getText().toString();
                num2= edit2.getText().toString();
                result= Double.parseDouble(num1)*Double.parseDouble(num2);
                result = (Math.round(result*100)/100.0);
                textResult.setText("계산결과:"+result.toString());

            }
        });
        btnDiv = findViewById(R.id.btnDiv);
        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1 = edit1.getText().toString();
                num2= edit2.getText().toString();
                result= Double.parseDouble(num1)/Double.parseDouble(num2);
                result = (Math.round(result*100)/100.0);
                textResult.setText("계산결과:"+result.toString());


            }
        });




    }
}